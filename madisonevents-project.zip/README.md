# madisonevents
Simple Next.js app to show Madison event listings from Isthmus via RSS feed.
